# dsh-go-delete-conversation

给 **dsh-go 手机 App** 的会话长按菜单加一项「删除会话」。DSH 本身没有删会话的功能，这个插件补上。

## 它做什么

在会话列表里长按（或点每条右边的「…」）打开菜单，里面会多一行 **删除会话**，位置紧跟在官方「归档」后面。
点它 → 弹确认框 → 确认即永久删除，然后：

1. 删掉 `$DSH_HOME/sessions/<项目>/<会话id>/` 整个日志目录；
2. 删掉 `$DSH_HOME/storages/session_projcache/sessions/<会话id>.json` 投影缓存；
3. 从 workspace.json 的工作区归属和归档列表里摘掉它（走活的 `WorkspaceRegistry`，不裸改文件）；
4. 广播 `api-session/removed`，让其它开着的客户端立刻把那一行去掉。

正在跑回合的会话会被拒绝。删了不可恢复。

## 为什么能出现在手机上

这一行来自 Web 客户端插槽 `sidebar.workspaces.session.menu.item`（官方 pin=100 / rename=200 /
fork=300 / archive=400 / session-id=450，本插件 order=420）。dsh-go 的 App 界面渲染的正是这套插槽，
所以手机上也能点到 —— 这一点和很多人的直觉相反，但 `$DSH_HOME/cache/dsh-go-bridge/occupancy.json`
里能直接看到这个 slot 的占用记录。

宿主半边负责真删：浏览器半边通过 `POST /dsh-go-delete-conversation/delete` 让宿主去动文件，
路由只接受本机回环、非代理转发、且被 connection 服务认可的请求。

## 「归档」保持原样

「归档」恢复成它本来的意思：只是藏起来，不删。想让归档连带着删，在插件目录放一个
`archive-deletes.on` 文件：

```sh
touch ~/.dsh/dsh-go/plugins/dsh-go-delete-conversation/archive-deletes.on
```

（用 npm 装的话，这个目录是 `~/.dsh/profiles/web/node_modules/dsh-go-delete-conversation/`。）

## 装

```sh
dsh plugin --profile web add dsh-go-delete-conversation
```

本地开发时可以直接指向目录：

```sh
dsh plugin --profile web add ./dsh-go-delete-conversation
```

装完重启一次 DSH 引擎（手机 App 里重开会话或杀进程重进），长按菜单里就会出现。

## 版本说明

- **0.2.0** 去掉了原生面板和输入框上方的「删会话」按钮，只保留长按菜单这一个入口。
  那两个入口在手机上要点好几层才能到，实际用起来碍事。
- **0.1.0** 首发版本，带原生面板。

## 安全边界

- 只删 `$DSH_HOME/sessions/` 底下、名字匹配 `^[A-Za-z0-9-]{6,80}$` 的目录，路径穿越在 id 校验处就挡掉；
- 不碰 `accounts.json`、配置文件、工作区数据以外的任何东西；
- 不联网，不上报，没有遥测。

## 许可

MIT
